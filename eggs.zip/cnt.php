<?php 

include ("functions/functions.php");
session_start();
?>
 <?php total_items();?>